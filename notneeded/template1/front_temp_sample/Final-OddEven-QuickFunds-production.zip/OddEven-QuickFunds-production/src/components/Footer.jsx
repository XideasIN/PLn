import React from "react";
import { Link, useNavigate } from "react-router-dom";

const Footer = () => {
  const navigate = useNavigate();

  const handleAnchorNavigation = (anchorId) => {
    // Navigate to home page first
    navigate('/');
    
    // Wait for navigation to complete, then scroll to the anchor
    setTimeout(() => {
      const element = document.getElementById(anchorId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <footer className="footer-box" >
      <div className="container">
        <div className="row justify-content-between">
          <div className="col-lg-4">
            <h3 className="footer-title">Our Office</h3>
            <ul className="footer-ul-contact">
              <li>
                <a href="#">
                  <i className="bi bi-geo-alt-fill footer-contact-icons"></i>
                  700 Well St. #308,<br /> NV 89002
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-telephone-fill footer-contact-icons"></i>
                  1 888 489 8189
                </a>
              </li>
              <li>
                <a href="#">
                  <i className="bi bi-envelope-fill footer-contact-icons"></i>
                  cs@pulse.online
                </a>
              </li>
            </ul>
          </div>
          <div className="col-lg-4">
            <h3 className="footer-title">Quick Links</h3>
            <ul>
              <li>
                <button 
                  className="btn btn-link p-0 text-decoration-none"
                  onClick={() => handleAnchorNavigation('faq')}
                >
                  <i className="bi bi-chevron-right pe-2"></i>
                  FAQ's
                </button>
              </li>
              <li>
                <button 
                  className="btn btn-link p-0 text-decoration-none"
                  onClick={() => handleAnchorNavigation('about')}
                >
                  <i className="bi bi-chevron-right pe-2"></i>
                  About Us
                </button>
              </li>
              <li>
                <button 
                  className="btn btn-link p-0 text-decoration-none"
                  onClick={() => handleAnchorNavigation('contact')}
                >
                  <i className="bi bi-chevron-right pe-2"></i>
                  Contact Us
                </button>
              </li>
              <li>
                <Link to="/terms-conditions">
                  <i className="bi bi-chevron-right pe-2"></i>
                  Terms & Condition
                </Link>
              </li>
              <li>
                <Link to="/privacy-policy">
                  <i className="bi bi-chevron-right pe-2"></i>
                  Privacy
                </Link>
              </li>
            </ul>
          </div>
          <div className="col-lg-4">
            <h3 className="footer-title">Business Hours</h3>
            <div className="position-relative">
              <p className="workday-title">Monday - Friday</p>
              <p className="mb-0">9:00am - 05:00pm</p>
            </div>
            <div className="position-relative">
              <p className="workday-title">Saturday</p>
              <p className="mb-0">09:00am - 02:00pm</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
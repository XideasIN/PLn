import HeroSection from './HeroSection'
import ServicesSection from './ServicesSection'
import HowWeWorkSection from './HowWeWorkSection'
import AboutSection from './AboutSection'
import FaqSection from './FAQ'

const Home = () => {
  return (
    <main className="main">
      <HeroSection />
      <ServicesSection />
      <HowWeWorkSection />
      <FaqSection />
      <AboutSection />
    </main>
  );
};

export default Home;